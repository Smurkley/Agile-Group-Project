﻿/// Mohamed Ali NOUIRA
/// http://www.sweetmit.com
/// http://www.mohamedalinouira.com
/// https://github.com/medalinouira
/// Copyright © Mohamed Ali NOUIRA. All rights reserved.

using Unity;
using Unity.Lifetime;
using Android1.Services;
using Android1.IServices;
using Android1.IViewModels;
using Xamarin.Forms.Popups;
using Xamarin.Forms.Internals;
using Xamarin.Forms.Navigation;

namespace Android1.ViewModels
{
    public class ViewModelLocator
    {
        private static IUnityContainer _container { get; set; }

        [Preserve]
        public ViewModelLocator()
        {
            _container = new UnityContainer();
            
            _container.RegisterType<ISignInViewModel, SignInViewModel>(new ContainerControlledLifetimeManager());
            _container.RegisterType<ISignUpViewModel, SignUpViewModel>(new ContainerControlledLifetimeManager());
            _container.RegisterType<IForgotPasswordViewModel, ForgotPasswordViewModel>(new ContainerControlledLifetimeManager());

            _container.RegisterType<IHomeViewModel, HomeViewModel>(new ContainerControlledLifetimeManager());
            _container.RegisterType<IDetailsViewModel, DetailsViewModel>(new ContainerControlledLifetimeManager());

            _container.RegisterType<IUserServices, UserServices>();
            _container.RegisterType<IPopupsService, PopupsService>();
            _container.RegisterType<INavigationService, NavigationService>(new ContainerControlledLifetimeManager());
        }

        public ISignInViewModel SignIn
        {
            get
            {
                return _container.Resolve<ISignInViewModel>();
            }
        }

        public ISignUpViewModel SignUp
        {
            get
            {
                return _container.Resolve<ISignUpViewModel>();
            }
        }

        public IForgotPasswordViewModel ForgotPassword
        {
            get
            {
                return _container.Resolve<IForgotPasswordViewModel>();
            }
        }

        public IHomeViewModel Home
        {
            get
            {
                return _container.Resolve<IHomeViewModel>();
            }
        }

        public IDetailsViewModel Details
        {
            get
            {
                return _container.Resolve<IDetailsViewModel>();
            }
        }
    }
}
